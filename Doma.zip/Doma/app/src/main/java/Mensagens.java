package com.example.doma;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class Mensagens {
    private TextToSpeech tts;

    public Mensagens(Context context) {
        tts = new TextToSpeech(context, status -> {
            if (status != TextToSpeech.ERROR) {
                tts.setLanguage(Locale.US);
            }
        });
    }

    public void speak(String text) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }
}



