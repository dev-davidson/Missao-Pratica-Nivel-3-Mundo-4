// settings.gradle.kts
rootProject.name = "Doma"
include(":app")
